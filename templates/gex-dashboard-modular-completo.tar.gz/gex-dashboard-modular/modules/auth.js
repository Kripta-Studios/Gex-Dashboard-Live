// auth.js - Lógica de autenticación

import { AUTH_CONFIG, API_ENDPOINTS } from './config.js';

/**
 * Hash SHA-256
 */
export async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return hashHex;
}

/**
 * Verificar login con servidor
 */
export async function checkLogin() {
  const emailInput = document.getElementById("login-email").value.trim();
  const passInput = document.getElementById("login-pass").value;
  const errorDiv = document.getElementById("login-error");
  const btn = document.querySelector(".login-btn");

  errorDiv.innerText = "";
  btn.innerText = "VERIFYING...";

  try {
    const response = await fetch(API_ENDPOINTS.LOGIN, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: emailInput, password: passInput })
    });

    const data = await response.json();

    if (response.ok && data.status === "ok") {
      sessionStorage.setItem("gex_auth_token", data.token);
      sessionStorage.setItem("gex_user_role", data.role);
      return { success: true, role: data.role };
    } else {
      errorDiv.innerText = "Invalid credentials.";
      btn.innerText = "AUTHENTICATE";
      return { success: false };
    }
  } catch (e) {
    console.error(e);
    errorDiv.innerText = "Server connection failed.";
    btn.innerText = "AUTHENTICATE";
    return { success: false };
  }
}

/**
 * Conceder acceso después de login exitoso
 */
export function grantAccess(role) {
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("app-wrapper").style.display = "flex";
  
  // LOGICA ADMIN: Mostrar botón IB
  if (role === 'ADMIN') {
    const ibBtn = document.getElementById("btn-ib");
    if (ibBtn) ibBtn.style.display = "inline-block";
  }
}

/**
 * Verificar sesión existente
 */
export function checkSession() {
  const token = sessionStorage.getItem("gex_auth_token");
  const role = sessionStorage.getItem("gex_user_role");
  return token ? { valid: true, role } : { valid: false };
}
