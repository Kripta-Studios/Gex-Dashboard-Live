// state.js - Gestión del estado global de la aplicación

/**
 * Estado global de la aplicación
 */
export const appState = {
  tabs: [{ id: 0, name: "Default", charts: [] }],
  currentTabId: 0,
  tabCounter: 1,
  refreshIntervalId: null,
  realSpotSPX: 0,
  historyDebounceTimer: null,
  currentHistoryTimeEST: null
};

/**
 * Obtener tab actual
 */
export function getCurrentTab() {
  return appState.tabs.find((t) => t.id === appState.currentTabId);
}

/**
 * Obtener charts del tab actual
 */
export function getCurrentCharts() {
  const tab = getCurrentTab();
  return tab ? tab.charts : [];
}

/**
 * Agregar chart al tab actual
 */
export function addChartToCurrent(data, params) {
  const tab = getCurrentTab();
  if (tab) {
    tab.charts.push({
      data: data,
      greek: params.greek,
      inputTicker: params.ticker,
      inputExp: params.exp,
      type: params.type || 'heatmap'
    });
  }
}

/**
 * Remover chart del tab actual
 */
export function removeChart(index) {
  const tab = getCurrentTab();
  if (tab) {
    tab.charts.splice(index, 1);
  }
}

/**
 * Cambiar a un tab específico
 */
export function switchTab(id) {
  appState.currentTabId = id;
}

/**
 * Agregar nuevo tab
 */
export function addNewTab() {
  const newTab = {
    id: appState.tabCounter++,
    name: `Tab ${appState.tabCounter}`,
    charts: []
  };
  appState.tabs.push(newTab);
  return newTab;
}

/**
 * Cerrar tab
 */
export function closeTab(id) {
  if (appState.tabs.length === 1) return false;
  
  const idx = appState.tabs.findIndex((t) => t.id === id);
  if (idx === -1) return false;
  
  appState.tabs.splice(idx, 1);
  
  if (appState.currentTabId === id) {
    appState.currentTabId = appState.tabs[Math.max(0, idx - 1)].id;
  }
  
  return true;
}

/**
 * Renombrar tab
 */
export function renameTab(id, newName) {
  const tab = appState.tabs.find((t) => t.id === id);
  if (tab) {
    tab.name = newName;
    return true;
  }
  return false;
}
