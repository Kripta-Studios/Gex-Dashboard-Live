// storage.js - Gestión de layouts y persistencia en localStorage

import { appState } from './state.js';
import { getTodayString } from './utils.js';
import { fetchWithRetry, fetchFourierData, fetchIBData } from './api.js';

const STORAGE_KEY = "gex_dashboard_tabs_v1";

/**
 * Guardar todos los layouts en localStorage
 */
export function saveAllLayouts() {
  try {
    const themeSelect = document.querySelector("select[onchange*='changePalette']");
    const currentTheme = themeSelect ? themeSelect.value : 'default';
    
    const todayStr = getTodayString();

    const cleanTabs = appState.tabs.map((t) => ({
      id: t.id,
      name: t.name,
      charts: t.charts.filter(c => c.inputTicker).map((c) => {
        let dateToSave = null;
        if (c.type === 'fourier' || c.type === 'ib') {
          if (c.dateStr === todayStr) {
            dateToSave = "LIVE";
          } else {
            dateToSave = c.dateStr;
          }
        }

        return {
          ticker: c.inputTicker,
          exp: c.inputExp,
          greek: c.greek,
          type: c.type,
          savedDate: dateToSave
        };
      }),
    }));

    const data = {
      autoRefresh: document.getElementById("auto-refresh")?.checked || false,
      theme: currentTheme,
      tabs: cleanTabs,
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));

    const totalCharts = cleanTabs.reduce((acc, t) => acc + t.charts.length, 0);
    console.log(`[SAVE] Saved ${totalCharts} charts.`);
    
    const btn = document.querySelector('button[onclick*="saveAllLayouts"]');
    if (btn) {
      const old = btn.innerText;
      btn.innerText = "SAVED ✓";
      setTimeout(() => (btn.innerText = old), 1000);
    }
    
    return true;
  } catch (e) {
    console.error("Save failed:", e);
    alert("Error saving layout. Check console.");
    return false;
  }
}

/**
 * Cargar layouts guardados desde localStorage
 */
export async function loadSavedLayouts() {
  const s = localStorage.getItem(STORAGE_KEY);
  if (!s) return false;
  
  const wrapper = document.getElementById("charts-wrapper");
  if (wrapper) {
    wrapper.innerHTML = '<div style="color:var(--accent-blue); margin:auto; text-align:center; font-family:monospace;">RESTORING LAYOUT...</div>';
  }

  try {
    const obj = JSON.parse(s);

    // Restaurar configuración de auto-refresh
    if (obj.autoRefresh !== undefined) {
      const chk = document.getElementById("auto-refresh");
      if (chk) chk.checked = obj.autoRefresh;
    }

    // Restaurar tema
    if (obj.theme) {
      const themeSelect = document.querySelector("select[onchange*='changePalette']");
      if (themeSelect) {
        themeSelect.value = obj.theme;
        // Llamar función de cambio de tema si existe
        if (window.changePalette) {
          window.changePalette(obj.theme);
        }
      }
    }
    
    if (obj.tabs && Array.isArray(obj.tabs)) {
      appState.tabs = obj.tabs.map((t) => ({ id: t.id, name: t.name, charts: [] }));
      
      if (appState.tabs.length > 0) {
        appState.tabCounter = Math.max(...appState.tabs.map((t) => t.id)) + 1;
        appState.currentTabId = appState.tabs[0].id;
      } else {
        appState.tabs = [{ id: 0, name: "Default", charts: [] }];
        appState.currentTabId = 0;
      }

      const todayStr = getTodayString();

      // Cargar charts de cada tab
      const tabPromises = obj.tabs.map(async (tData) => {
        if (!tData.charts) return;

        const chartPromises = tData.charts.map(async (cConf) => {
          if (!cConf.ticker) return null;

          // Determinar tipo si no está especificado
          if (!cConf.type) {
            if (cConf.exp === 'fourier') cConf.type = 'fourier';
            else if (cConf.exp === 'ib') cConf.type = 'ib';
            else cConf.type = 'heatmap';
          }

          let d = null;
          let loadedDateStr = null;

          // Cargar según tipo
          if (cConf.type === 'fourier' || cConf.type === 'ib') {
            if (cConf.savedDate && cConf.savedDate !== "LIVE") {
              loadedDateStr = cConf.savedDate;
            } else {
              loadedDateStr = todayStr;
            }

            if (cConf.type === 'fourier') {
              d = await fetchFourierData(cConf.ticker, loadedDateStr);
            } else {
              d = await fetchIBData(cConf.ticker, loadedDateStr);
            }
          } else {
            d = await fetchWithRetry(cConf.ticker, cConf.exp, 1, 0);
          }
          
          if (!d) {
            console.warn(`[Layout] Skipped ${cConf.ticker} (${cConf.type}). No data.`);
            return null;
          }

          return {
            data: d,
            greek: cConf.greek,
            inputTicker: cConf.ticker,
            inputExp: cConf.exp,
            type: cConf.type,
            dateStr: loadedDateStr
          };
        });

        const resolvedCharts = await Promise.all(chartPromises);
        const tab = appState.tabs.find((t) => t.id === tData.id);
        if (tab) {
          tab.charts = resolvedCharts.filter((c) => c !== null);
        }
      });

      await Promise.all(tabPromises);
      return true;
    }
  } catch (e) {
    console.error("Load failed:", e);
    return false;
  }
  
  return false;
}

/**
 * Tomar snapshot del layout actual
 */
export function takeSnapshot() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const key = `gex_snapshot_${timestamp}`;
  
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    if (current) {
      localStorage.setItem(key, current);
      console.log(`[SNAPSHOT] Saved as ${key}`);
      alert(`Snapshot saved: ${timestamp}`);
      return true;
    }
  } catch (e) {
    console.error("Snapshot failed:", e);
    return false;
  }
  
  return false;
}
