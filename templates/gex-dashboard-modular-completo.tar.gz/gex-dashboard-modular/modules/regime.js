// regime.js - Lógica de análisis de régimen de mercado

import { formatK } from './utils.js';

/**
 * Generar HTML para el análisis de régimen
 */
export function generateRegimeHTML(ticker, greek, spot, netValue, spotStrikeValue, netChangeHTML = "", spotChangeHTML = "") {
  let regimeText = "",
    behaviorText = "",
    biasText = "",
    regimeColorVar = "--text-dim";
  
  const isLocalPos = spotStrikeValue >= 0;
  const isNetPos = netValue >= 0;

  const isAligned = isLocalPos === isNetPos;
  const alignmentText = isAligned ? "CONVERGENT" : "DIVERGENT";
  const alignmentColor = isAligned
    ? "var(--accent-green)"
    : "var(--accent-red)";

  if (greek === "gamma" || greek === "dgex") {
    if (isLocalPos) {
      regimeText = "POSITIVE (STICKY)";
      behaviorText = "Dealer sells strength / buys weakness. Low Volatility.";
      regimeColorVar = "--pos-high";
    } else {
      regimeText = "NEGATIVE (ACCEL)";
      behaviorText = "Dealer buys strength / sells weakness. High Volatility.";
      regimeColorVar = "--neg-high";
    }
    biasText = isNetPos ? "Bullish Exposure" : "Bearish Exposure";
  } else if (greek === "delta") {
    if (isNetPos) {
      regimeText = "NET LONG";
      behaviorText = "Dealers are Long. Market needs to sell to hedge.";
      regimeColorVar = "--pos-high";
    } else {
      regimeText = "NET SHORT";
      behaviorText = "Dealers are Short. Market needs to buy to hedge.";
      regimeColorVar = "--neg-high";
    }
    biasText = isLocalPos ? "Local Support" : "Local Resistance";
  } else if (greek === "vanna") {
    if (isLocalPos) {
      regimeText = "POS VANNA";
      behaviorText = "IV Drop = Buying | IV Spike = Selling.";
      regimeColorVar = "--pos-high";
    } else {
      regimeText = "NEG VANNA";
      behaviorText = "IV Drop = Selling | IV Spike = Buying.";
      regimeColorVar = "--neg-high";
    }
    biasText = "Vol Impact";
  } else if (greek === "zomma") {
    if (isLocalPos) {
      regimeText = "POS ZOMMA";
      behaviorText = "Gamma increases as Vol drops (Stabilizing).";
      regimeColorVar = "--pos-high";
    } else {
      regimeText = "NEG ZOMMA";
      behaviorText = "Gamma increases as Vol rises (Destabilizing).";
      regimeColorVar = "--neg-high";
    }
    biasText = "Gamma convexity";
  } else {
    regimeText = isLocalPos ? "LOCAL POS" : "LOCAL NEG";
    behaviorText = "Standard hedging mechanics apply.";
    regimeColorVar = isLocalPos ? "--pos-high" : "--neg-high";
    biasText = `Net: ${formatK(netValue)}`;
  }

  const borderColor = `var(${regimeColorVar})`;
  const formattedSpot = spot.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return `
    <div class="regime-wrapper" style="border-left-color: ${borderColor};">
      <div class="regime-header-toggle" onclick="this.parentElement.classList.toggle('active')">
        <span style="color: ${borderColor};">${greek.toUpperCase()} ANALYSIS</span>
        <span class="regime-toggle-icon">▼</span>
      </div>

      <div class="regime-content">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 8px; margin-bottom: 8px;">
          <div>
            <div style="font-size: 9px; color: var(--text-dim); text-transform: uppercase;">Current Spot</div>
            <div style="font-size: 13px; font-weight: 700; color: white;">${formattedSpot}</div>
          </div>

          <div style="text-align: right;">
            <div style="font-size: 9px; color: var(--text-dim); text-transform: uppercase;">Net Exposure</div>
            <div style="font-size: 13px; font-weight: 700; color: var(${isNetPos ? "--pos-high" : "--neg-high"});">
              ${formatK(netValue)} 
              ${netChangeHTML} 
            </div>
          </div>

          <div>
            <div style="font-size: 9px; color: var(--text-dim); text-transform: uppercase;">Local Strike Exp</div>
            <div style="font-size: 13px; font-weight: 700; color: var(${isLocalPos ? "--pos-high" : "--neg-high"});">
              ${formatK(spotStrikeValue)} 
              ${spotChangeHTML} 
            </div>
          </div>

          <div style="text-align: right;">
            <div style="font-size: 9px; color: var(--text-dim); text-transform: uppercase;">Structure</div>
            <div style="font-size: 11px; font-weight: 700; color: ${alignmentColor}; letter-spacing: 0.5px;">${alignmentText}</div>
          </div>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
          <div style="display: flex; justify-content: space-between;">
            <span style="color: var(--text-dim);">Regime:</span>
            <span style="font-weight: 700; color: ${borderColor};">${regimeText}</span>
          </div>
          <div style="font-size: 10px; color: #ccc; font-style: italic; margin: 2px 0;">
            "${behaviorText}"
          </div>
          <div style="display: flex; justify-content: space-between; border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 4px; margin-top: 2px;">
            <span style="color: var(--text-dim);">Market Bias:</span>
            <span style="font-weight: 700; color: white;">${biasText}</span>
          </div>
        </div>
      </div>
    </div>
  `;
}
