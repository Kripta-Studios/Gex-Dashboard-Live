// api.js - Funciones para fetching de datos desde el servidor

import { API_ENDPOINTS, MAX_RETRIES, RETRY_DELAY } from './config.js';

/**
 * Fetch datos de chart (heatmap)
 */
export async function fetchChartData(ticker, exp) {
  try {
    const resp = await fetch(
      `/get_data?ticker=${ticker.toUpperCase()}&exp=${exp.toLowerCase()}`
    );
    if (!resp.ok) return null;
    return await resp.json();
  } catch (e) {
    console.error("fetchChartData error:", e);
    return null;
  }
}

/**
 * Fetch con reintentos
 */
export async function fetchWithRetry(ticker, exp, maxRetries = MAX_RETRIES, delay = RETRY_DELAY) {
  for (let i = 0; i < maxRetries; i++) {
    const data = await fetchChartData(ticker, exp);
    
    if (data && data.option_data && data.option_data.data && data.option_data.data.length > 0) {
      return data;
    }
    
    console.log(`[Retry ${i+1}/${maxRetries}] Waiting for data: ${ticker} ${exp}...`);
    await new Promise(resolve => setTimeout(resolve, delay));
  }
  return null;
}

/**
 * Fetch batch de múltiples charts
 */
export async function fetchBatchData(requests) {
  try {
    const response = await fetch(API_ENDPOINTS.GET_BATCH, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(requests)
    });
    
    return await response.json();
  } catch (e) {
    console.error("Batch update failed", e);
    return null;
  }
}

/**
 * Fetch datos de Fourier
 */
export async function fetchFourierData(ticker, dateStr) {
  try {
    const url = dateStr 
      ? `/get_fourier?ticker=${ticker}&date=${dateStr}`
      : `/get_fourier?ticker=${ticker}`;
    
    const resp = await fetch(url);
    if (!resp.ok) return null;
    return await resp.json();
  } catch (e) {
    console.error("fetchFourierData error:", e);
    return null;
  }
}

/**
 * Fetch datos de IB (Initial Balance)
 */
export async function fetchIBData(ticker, dateStr) {
  try {
    const url = dateStr 
      ? `/get_ib?ticker=${ticker}&date=${dateStr}`
      : `/get_ib?ticker=${ticker}`;
    
    const resp = await fetch(url);
    if (!resp.ok) return null;
    return await resp.json();
  } catch (e) {
    console.error("fetchIBData error:", e);
    return null;
  }
}

/**
 * Actualizar spots de mercado (SPX, NDX, etc.)
 */
export async function updateMarketSpots() {
  try {
    const resp = await fetch('/get_spots');
    if (!resp.ok) return;
    
    const spots = await resp.json();
    
    updateSpotElement('spot-spx-p', 'spot-spx-c', spots.SPX);
    updateSpotElement('spot-ndx-p', 'spot-ndx-c', spots.NDX);
    updateSpotElement('spot-rut-p', 'spot-rut-c', spots.RUT);
  } catch (e) {
    console.error("updateMarketSpots error:", e);
  }
}

function updateSpotElement(priceId, changeId, data) {
  const priceEl = document.getElementById(priceId);
  const changeEl = document.getElementById(changeId);
  
  if (priceEl && data) {
    priceEl.textContent = data.price.toFixed(2);
  }
  
  if (changeEl && data && data.change !== undefined) {
    const sign = data.change >= 0 ? '+' : '';
    changeEl.textContent = `${sign}${data.change.toFixed(2)}`;
    changeEl.style.color = data.change >= 0 ? 'var(--accent-green)' : 'var(--accent-red)';
  }
}
