// utils.js - Funciones de utilidad y formateo

/**
 * Formatear número en miles (k)
 */
export function formatK(n) {
  if (Math.abs(n) < 1) return "0";
  return parseInt(n).toLocaleString('en-US') + "k";
}

/**
 * Formatear cambio porcentual con color
 */
export function formatChangePct(current, previous) {
  if (previous === null || previous === undefined) return "";
  
  if (previous === 0) return ""; 

  const diff = current - previous;
  const pct = (diff / Math.abs(previous)) * 100;
  
  let colorStyle = "var(--text-dim)";
  let sign = "";
  
  if (pct > 0.001) {
    colorStyle = "var(--accent-green)";
    sign = "+";
  } else if (pct < -0.001) {
    colorStyle = "var(--accent-red)";
    sign = "";
  }

  return `<span style="color:${colorStyle}; font-size: 10px; font-weight: normal; margin-left: 4px;">(${sign}${pct.toFixed(2)}%)</span>`;
}

/**
 * Obtener minutos en EST
 */
export function getCurrentESTMinutes() {
  const now = new Date();
  const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
  const estOffset = -5 * 3600000; // EST = UTC-5
  const estTime = new Date(utc + estOffset);
  return estTime.getHours() * 60 + estTime.getMinutes();
}

/**
 * Actualizar reloj NY
 */
export function updateNYTime() {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const est = new Date(utc - 5 * 3600000);
  
  const h = String(est.getHours()).padStart(2, "0");
  const m = String(est.getMinutes()).padStart(2, "0");
  const s = String(est.getSeconds()).padStart(2, "0");
  
  const el = document.getElementById("ny-time");
  if (el) el.textContent = `${h}:${m}:${s}`;
}

/**
 * Scrub history - normalizar minutos EST
 */
export function scrubHistory(val) {
  const marketOpen = 570;  // 9:30
  const marketClose = 960; // 16:00
  
  if (val < marketOpen) return marketOpen;
  if (val > marketClose) return marketClose;
  return val;
}

/**
 * Generar ID único
 */
export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Debounce function
 */
export function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Parsear fecha en formato YYYYMMDD
 */
export function parseDate(dateStr) {
  if (!dateStr || dateStr === 'LIVE') return null;
  const year = dateStr.substring(0, 4);
  const month = dateStr.substring(4, 6);
  const day = dateStr.substring(6, 8);
  return new Date(`${year}-${month}-${day}`);
}

/**
 * Formatear fecha actual como YYYYMMDD
 */
export function getTodayString() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
}
