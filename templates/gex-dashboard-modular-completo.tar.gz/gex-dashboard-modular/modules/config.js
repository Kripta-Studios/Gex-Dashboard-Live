// config.js - Configuración y constantes globales

export const AUTH_CONFIG = {
  TARGET_EMAIL_HASH: "0f089be93d18d31f8ac42fc84ecd206bea41ffbde1df2a11dc1de1637822dcb7",
  TARGET_PASS_HASH: "9b068d00dba617e0e84667d11ac6eb934e8ca73f4102195095eeff8ccd3359e1"
};

export const THEME_PALETTES = {
  default: {
    '--bg-main': '#0a0a0a',
    '--bg-panel': '#111',
    // ... resto de colores
  },
  // otros temas...
};

export const API_ENDPOINTS = {
  LOGIN: '/login',
  GET_BATCH: '/get_batch',
  GET_FOURIER: '/get_fourier',
  GET_IB: '/get_ib'
};

export const REFRESH_INTERVAL = 30000; // 30 segundos
export const MAX_RETRIES = 10;
export const RETRY_DELAY = 500;
