# 🚀 Guía Rápida de Migración

## Antes (2300 líneas en 1 archivo) 😰

```
script.js (2300 líneas)
├── Authentication (26-98)
├── Initialization (100-318)
├── History Logic (320-425)
├── Data Fetching (428-463)
├── UI Features (464-494)
├── Tabs Management (496-578)
├── Drag & Drop (580-665)
├── Data Handlers (667-720)
├── Rendering (722-1097)
├── System (1128-1231)
├── Storage (1254-1432)
├── Spots Update (1434-1507)
├── Utils (1509-1624)
├── Fourier Charts (1626-1799)
├── IB Charts (2054-2234)
├── Tab DnD (2253-2288)
└── Utilities (2290-2317)
```

## Después (Estructura Modular) 😎

```
project/
├── main.js (300 líneas)          # Coordinador principal
├── modules/
│   ├── config.js (50)           # ⚙️  Configuración
│   ├── auth.js (80)             # 🔐 Autenticación
│   ├── state.js (120)           # 📊 Estado global
│   ├── api.js (150)             # 🌐 API calls
│   ├── utils.js (130)           # 🛠️  Utilidades
│   ├── heatmap.js (280)         # 📊 Heatmaps
│   ├── regime.js (110)          # 📈 Análisis
│   ├── storage.js (180)         # 💾 Persistencia
│   ├── fourier.js (200)         # 📉 Fourier
│   ├── ib.js (180)              # ⏰ IB Charts
│   └── tabs.js (100)            # 📑 Tabs
└── tests/                        # ✅ Testing
    └── *.test.js
```

**Resultado:** 
- ✅ Cada archivo < 300 líneas
- ✅ Responsabilidades claras
- ✅ Fácil de testear
- ✅ Fácil de mantener

## 🎯 Pasos de Migración

### Opción A: Migración Gradual (Recomendado)

```bash
# Paso 1: Crear estructura base
mkdir modules
mkdir tests

# Paso 2: Copiar módulos base creados
# (Ya están creados: config, auth, state, api, utils, heatmap, regime, storage)

# Paso 3: Actualizar HTML
# Cambiar: <script src="script.js"></script>
# Por:     <script type="module" src="main.js"></script>

# Paso 4: Probar que funciona
npm run dev

# Paso 5: Migrar funciones faltantes una a una
node migrate.js analyze          # Ver qué falta
node migrate.js extract fourier.js  # Extraer Fourier
node migrate.js extract ib.js       # Extraer IB
# etc...

# Paso 6: Validar
node migrate.js validate
```

### Opción B: Migración Completa (Rápido)

```bash
# Extraer todo de una vez
node migrate.js extract

# Revisar y ajustar imports/exports manualmente
# Probar
npm run dev
```

## 📝 Checklist de Migración

- [ ] Crear estructura de carpetas
- [ ] Copiar módulos base (8 archivos ya creados)
- [ ] Actualizar HTML para usar `type="module"`
- [ ] Extraer módulos faltantes:
  - [ ] fourier.js
  - [ ] ib.js
  - [ ] tabs.js
  - [ ] history.js
- [ ] Actualizar main.js con nuevos imports
- [ ] Probar cada funcionalidad:
  - [ ] Login
  - [ ] Cargar charts
  - [ ] Cambiar tabs
  - [ ] Guardar/Cargar layouts
  - [ ] Fourier charts
  - [ ] IB charts
  - [ ] Auto-refresh
- [ ] Optimizar con Vite (opcional)
- [ ] Agregar tests (opcional)

## 🔥 Comandos Útiles

```bash
# Desarrollo
npm run dev                    # Servidor de desarrollo

# Análisis
npm run analyze               # Analizar script.js original
npm run validate              # Validar módulos creados

# Build
npm run build                 # Build para producción
npm run preview               # Preview del build

# Testing (si se agrega)
npm run test                  # Correr tests
npm run test -- --watch       # Watch mode
```

## 💡 Tips de Migración

### 1. Mantén compatibilidad temporal

```javascript
// script.js (wrapper temporal)
import { init } from './main.js';

// Mantener referencias globales para debugging
window.DEBUG_APP_STATE = () => import('./modules/state.js');

init();
```

### 2. Usa aliases para imports limpios

```javascript
// Antes
import { formatK } from '../../../modules/utils.js';

// Después (con alias en vite.config.js)
import { formatK } from '@utils';
```

### 3. Debugging modular

```javascript
// Agregar en cada módulo
const MODULE_NAME = 'heatmap';
const log = (...args) => console.log(`[${MODULE_NAME}]`, ...args);

export function createHeatmapPanel(...) {
  log('Creating panel with', ...);
  // ...
}
```

### 4. Lazy loading para mejor performance

```javascript
// main.js
async function loadFourierChart() {
  const { createFourierPanel } = await import('./modules/fourier.js');
  return createFourierPanel(...);
}
```

## 🆘 Problemas Comunes

### ❌ "Cannot use import statement outside a module"

**Solución:** Agregar `type="module"` en el script tag:
```html
<script type="module" src="main.js"></script>
```

### ❌ "Failed to resolve module specifier"

**Solución:** Usar rutas relativas o configurar aliases:
```javascript
// ❌ Mal
import { x } from 'modules/utils.js';

// ✅ Bien
import { x } from './modules/utils.js';
```

### ❌ "ReferenceError: X is not defined"

**Solución:** Exportar e importar la función:
```javascript
// En el módulo
export function X() { ... }

// En main.js
import { X } from './modules/file.js';
window.X = X;  // Si se usa en onclick
```

### ❌ CORS errors en desarrollo

**Solución:** Usar servidor local:
```bash
npx http-server -p 8000 --cors
# O
npm run dev  # Con Vite
```

## 📚 Recursos Adicionales

- [ES Modules Guide](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)
- [Vite Documentation](https://vitejs.dev/)
- [JavaScript Design Patterns](https://www.patterns.dev/)

## 🎉 Beneficios Inmediatos

Después de migrar, tendrás:

1. ✅ **Código organizado** - Fácil de navegar
2. ✅ **Mejor performance** - Tree shaking automático
3. ✅ **Más rápido desarrollar** - Hot Module Replacement
4. ✅ **Fácil de testear** - Módulos independientes
5. ✅ **Mejor colaboración** - Múltiples devs sin conflictos
6. ✅ **Escalable** - Agregar features sin romper nada

---

**¿Listo para empezar?** 🚀

```bash
# Instalar dependencias
npm install

# Ver análisis del código actual
npm run analyze

# Comenzar migración
npm run extract

# ¡Probar!
npm run dev
```
