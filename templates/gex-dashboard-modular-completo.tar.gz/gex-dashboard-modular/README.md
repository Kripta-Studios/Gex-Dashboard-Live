# GEX Dashboard - Estructura Modular

## 📁 Estructura de Archivos

```
project/
├── index.html              # HTML principal
├── main.js                 # Punto de entrada y coordinador
└── modules/
    ├── config.js          # Configuración y constantes
    ├── auth.js            # Autenticación y login
    ├── state.js           # Gestión de estado global
    ├── api.js             # Fetching de datos del servidor
    ├── utils.js           # Utilidades y formateo
    ├── heatmap.js         # Renderizado de heatmaps
    ├── regime.js          # Análisis de régimen de mercado
    ├── storage.js         # Persistencia y localStorage
    ├── fourier.js         # Charts de Fourier (a crear)
    ├── ib.js              # Charts de Initial Balance (a crear)
    ├── tabs.js            # Gestión de tabs (opcional)
    ├── ui.js              # Componentes UI generales (opcional)
    └── charts.js          # Chart.js wrappers (opcional)
```

## 📦 Módulos Creados

### 1. **config.js** - Configuración
- Constantes de autenticación
- Paletas de temas
- Endpoints de API
- Configuración de intervalos

### 2. **auth.js** - Autenticación
- `sha256(message)` - Hash de contraseñas
- `checkLogin()` - Verificar credenciales
- `grantAccess(role)` - Conceder acceso
- `checkSession()` - Verificar sesión existente

### 3. **state.js** - Estado Global
- `appState` - Objeto de estado central
- `getCurrentTab()` - Obtener tab activo
- `getCurrentCharts()` - Obtener charts del tab
- `addChartToCurrent()` - Agregar chart
- `removeChart()` - Eliminar chart
- `switchTab()` - Cambiar de tab
- `addNewTab()` - Crear nuevo tab
- `closeTab()` - Cerrar tab
- `renameTab()` - Renombrar tab

### 4. **api.js** - API y Datos
- `fetchChartData(ticker, exp)` - Fetch heatmap data
- `fetchWithRetry()` - Fetch con reintentos
- `fetchBatchData()` - Fetch múltiples charts
- `fetchFourierData()` - Fetch datos Fourier
- `fetchIBData()` - Fetch datos IB
- `updateMarketSpots()` - Actualizar spots SPX/NDX/RUT

### 5. **utils.js** - Utilidades
- `formatK(n)` - Formatear números en miles
- `formatChangePct()` - Formatear cambio porcentual
- `getCurrentESTMinutes()` - Obtener minutos EST
- `updateNYTime()` - Actualizar reloj NY
- `scrubHistory()` - Normalizar minutos
- `getTodayString()` - Fecha actual YYYYMMDD
- `debounce()` - Función debounce

### 6. **heatmap.js** - Heatmaps
- `createHeatmapPanel(chartObj, index)` - Crear panel de heatmap
- `alignChartToSpot(panel)` - Centrar en spot price
- Lógica completa de:
  - Agregación de datos por strike
  - Tracking de cambios (nominal)
  - Cálculo de top 5 positivos/negativos
  - Renderizado de barras con colores

### 7. **regime.js** - Análisis de Régimen
- `generateRegimeHTML()` - Generar HTML de análisis
- Lógica de interpretación por greek:
  - Gamma/DGEX: Positive/Negative regimes
  - Delta: Net Long/Short
  - Vanna: Positive/Negative vanna
  - Zomma: Positive/Negative zomma

### 8. **storage.js** - Persistencia
- `saveAllLayouts()` - Guardar en localStorage
- `loadSavedLayouts()` - Cargar desde localStorage
- `takeSnapshot()` - Crear snapshot
- Gestión de fechas LIVE vs históricas

## 🔧 Cómo Usar

### Opción 1: Importar en HTML (ES Modules)

```html
<!DOCTYPE html>
<html>
<head>
    <title>GEX Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Tu HTML aquí -->
    
    <script type="module" src="main.js"></script>
</body>
</html>
```

### Opción 2: Build con Bundler (Webpack/Vite/Rollup)

```bash
# Instalar dependencias
npm install

# Build con Vite (recomendado)
npm run build

# O con Webpack
webpack --config webpack.config.js
```

### Opción 3: Uso directo (sin build)

Los navegadores modernos soportan ES modules nativamente. Solo necesitas:

1. Servir los archivos con un servidor web (no file://)
2. Usar `type="module"` en el script tag

```bash
# Servidor simple con Python
python -m http.server 8000

# O con Node
npx http-server
```

## 🚀 Migración desde script.js Monolítico

### Paso 1: Mantener compatibilidad

Puedes mantener el `script.js` original y migrar gradualmente:

```javascript
// script.js (temporal)
import { init } from './main.js';
init();
```

### Paso 2: Actualizar referencias

Buscar y reemplazar las referencias globales:

```javascript
// Antes
function removeChart(index) { ... }

// Después
import { removeChart } from './modules/state.js';
window.removeChart = removeChart;  // Para onclick handlers
```

### Paso 3: Funciones pendientes

Las siguientes funciones aún necesitan ser modularizadas:

- **fourier.js** - Charts de Fourier (líneas 1626-1799)
- **ib.js** - Charts de IB (líneas 2054-2234)
- **tabs.js** - Drag & drop de tabs (líneas 2253-2288)
- **history.js** - Lógica de historial (líneas 320-425)
- **ui.js** - Componentes UI (zen mode, paletas, etc.)

## 📋 Ventajas de la Estructura Modular

1. **Mantenibilidad** 
   - Cada módulo tiene una responsabilidad clara
   - Fácil encontrar y modificar código

2. **Testabilidad**
   - Módulos independientes son fáciles de testear
   - Mock de dependencias simplificado

3. **Reutilización**
   - Importar solo lo necesario
   - Compartir módulos entre proyectos

4. **Colaboración**
   - Múltiples desarrolladores pueden trabajar en paralelo
   - Menos conflictos de merge

5. **Performance**
   - Tree shaking automático (eliminación de código no usado)
   - Lazy loading de módulos

6. **Escalabilidad**
   - Agregar features sin tocar código existente
   - Arquitectura clara para crecer

## 🔄 Próximos Pasos Recomendados

1. **Crear módulos faltantes:**
   ```
   modules/fourier.js     - Extraer lógica Fourier
   modules/ib.js          - Extraer lógica IB
   modules/tabs.js        - Extraer gestión de tabs
   modules/history.js     - Extraer historial
   ```

2. **Agregar TypeScript (opcional):**
   ```typescript
   // types.d.ts
   export interface ChartData { ... }
   export interface TabConfig { ... }
   ```

3. **Agregar tests:**
   ```javascript
   // tests/utils.test.js
   import { formatK } from '../modules/utils.js';
   
   test('formatK formats numbers correctly', () => {
     expect(formatK(1000)).toBe('1,000k');
   });
   ```

4. **Configurar bundler:**
   ```javascript
   // vite.config.js
   export default {
     build: {
       rollupOptions: {
         input: {
           main: 'main.js'
         }
       }
     }
   }
   ```

## 💡 Consejos

- Mantén los módulos pequeños (< 300 líneas)
- Un módulo = una responsabilidad
- Exporta solo lo necesario
- Documenta funciones públicas
- Usa nombres descriptivos

## 🐛 Debugging

Para debug en módulos:

```javascript
// En cualquier módulo
console.log('[MODULE_NAME]', ...args);

// O con etiquetas
export const DEBUG = true;
if (DEBUG) console.log(...);
```

## 📚 Recursos

- [ES Modules MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)
- [Vite Guide](https://vitejs.dev/guide/)
- [JavaScript Module Pattern](https://www.patterns.dev/posts/module-pattern/)
