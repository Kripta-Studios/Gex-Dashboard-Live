import uuid
import threading
import time
import http.server
import socketserver
import os
import glob
import urllib.parse
import re
import logging
from datetime import datetime

# --- CONFIGURATION ---
PORT = 8609
DATA_FOLDER = "json_data"
TEMPLATE_FOLDER = "templates"
LOG_FILE = "servidor_logs.txt"
MOVIE_DIRECTORY = "/home/kripta/Movies"
MOVIE_FILENAME = "oppenheimer.mp4"

# MEMORIA RAM GLOBAL
LATEST_DATA_CACHE = {}
CACHE_LOCK = threading.Lock()

USERS = {
    "admin@flowgreeks.com": {"pass": "admin123", "role": "ADMIN"},
    "flowgreeks@email.com": {"pass": "FlowGreeksPlotting", "role": "USER"},
}
SESSIONS = {}

# Configure Logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


class ThreadedReusableServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class ExposureDataHandler(http.server.SimpleHTTPRequestHandler):

    def log_message(self, format, *args):
        """
        Sobrescribe el método por defecto para guardar logs.
        Detecta la IP real si se usa un Proxy Inverso (Nginx/Apache).
        """
        x_forwarded = self.headers.get("X-Forwarded-For")
        x_real = self.headers.get("X-Real-IP")

        if x_forwarded:
            client_ip = x_forwarded.split(',')[0].strip()
        elif x_real:
            client_ip = x_real
        else:
            client_ip = self.client_address[0]

        status_message = format % args
        log_entry = f"IP: {client_ip: <15} | REQ: {self.requestline} | RES: {status_message}"
        logging.info(log_entry)

    def smart_glob(self, ticker, exp, date_str=None):
        ticker_vars = list(set([ticker.upper(), ticker.lower(), ticker]))
        exp_vars = list(set([exp.lower(), exp.upper(), exp]))

        found_files = []

        for t in ticker_vars:
            for e in exp_vars:
                if date_str:
                    pattern = os.path.join(
                        DATA_FOLDER, f"*{t}*{e}*ExposureData*{date_str}*.json"
                    )
                else:
                    pattern = os.path.join(DATA_FOLDER, f"*{t}*{e}*ExposureData*.json")

                matches = glob.glob(pattern)
                if matches:
                    found_files.extend(matches)

        return sorted(list(set(found_files)))

    def serve_video(self, full_path):
        """Streams video with Range support"""
        try:
            file_size = os.path.getsize(full_path)
            range_header = self.headers.get("Range", "").strip()
            start, end = 0, file_size - 1

            if range_header:
                m = re.search(r"bytes=(\d+)-(\d*)", range_header)
                if m:
                    start = int(m.group(1))
                    if m.group(2):
                        end = int(m.group(2))

            length = end - start + 1
            self.send_response(206)
            self.send_header("Content-Type", "video/x-matroska")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
            self.send_header("Content-Length", str(length))
            self.end_headers()

            with open(full_path, "rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk_size = min(65536, remaining)
                    data = f.read(chunk_size)
                    if not data:
                        break
                    try:
                        self.wfile.write(data)
                        remaining -= len(data)
                    except (BrokenPipeError, ConnectionResetError):
                        break
        except Exception as e:
            logging.error(f"Video Error: {e}")

    def do_POST(self):
        # --- LOGIN ENDPOINT ---
        if self.path == "/login":
            content_len = int(self.headers.get("Content-Length", 0))
            post_body = self.rfile.read(content_len)

            try:
                import json

                creds = json.loads(post_body)
                email = creds.get("email")
                password = creds.get("password")

                user = USERS.get(email)

                if user and user["pass"] == password:
                    token = str(uuid.uuid4())
                    role = user["role"]

                    with CACHE_LOCK:
                        SESSIONS[token] = role

                    response = {"status": "ok", "token": token, "role": role}
                    self.send_response(200)
                else:
                    response = {"status": "error", "message": "Invalid credentials"}
                    self.send_response(401)

                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(response).encode("utf-8"))

            except Exception as e:
                self.send_error(500, str(e))
            return

        # --- BATCH ENDPOINT ---
        if self.path == "/get_batch":
            content_len = int(self.headers.get("Content-Length", 0))
            post_body = self.rfile.read(content_len)

            import json

            try:
                request_data = json.loads(post_body)
                response_data = {}

                with CACHE_LOCK:
                    for item in request_data:
                        t = item.get("ticker").upper()
                        e = item.get("exp").lower()
                        key = f"{t}_{e}"

                        if key in LATEST_DATA_CACHE:
                            response_data[key] = json.loads(
                                LATEST_DATA_CACHE[key]["content"]
                            )
                        else:
                            response_data[key] = None

                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(response_data).encode("utf-8"))

            except Exception as e:
                self.send_error(500, str(e))
            return

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path_only = parsed_url.path

        # 1. SERVIR HTML
        if path_only == "/" or path_only == "/index.html":
            index_path = os.path.join(TEMPLATE_FOLDER, "index.html")
            if os.path.exists(index_path):
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                with open(index_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_error(404, f"Falta {index_path}")
            return

        # 2. SERVIR CSS
        if path_only.endswith(".css"):
            filename = path_only.lstrip("/")
            file_path = os.path.join(TEMPLATE_FOLDER, filename)
            if os.path.exists(file_path):
                self.send_response(200)
                self.send_header("Content-type", "text/css")
                self.end_headers()
                with open(file_path, "rb") as f:
                    self.wfile.write(f.read())
                return
            else:
                self.send_error(404)
                return

        # 3. SERVIR JS (NUEVO: Incluye módulos)
        if path_only.endswith(".js"):
            filename = path_only.lstrip("/")
            
            # Intentar en TEMPLATE_FOLDER directamente (main.js)
            file_path = os.path.join(TEMPLATE_FOLDER, filename)
            
            # Si no existe, intentar en modules/ (para imports)
            if not os.path.exists(file_path) and filename.startswith("modules/"):
                file_path = os.path.join(TEMPLATE_FOLDER, filename)
            
            if os.path.exists(file_path):
                self.send_response(200)
                self.send_header("Content-type", "application/javascript")
                # IMPORTANTE: Agregar header para ES modules
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                with open(file_path, "rb") as f:
                    self.wfile.write(f.read())
                return
            else:
                self.send_error(404, f"File not found: {filename}")
                return

        # 4. API ENDPOINTS (resto del código sin cambios)
        # ... continúa con el resto de tu servidor.py original
        
        # Ejemplo simplificado - mantén tu lógica completa:
        if self.path.startswith("/get_data"):
            # Tu lógica de get_data
            pass
        
        if self.path.startswith("/get_fourier"):
            # Tu lógica de fourier
            pass
            
        if self.path.startswith("/get_ib"):
            # Tu lógica de IB
            pass
            
        if self.path.startswith("/get_spots"):
            # Tu lógica de spots
            pass

        # Video endpoint
        if self.path.startswith("/video/"):
            movie_path = os.path.join(MOVIE_DIRECTORY, MOVIE_FILENAME)
            if os.path.exists(movie_path):
                self.serve_video(movie_path)
            else:
                self.send_error(404, "Movie not found")
            return

        self.send_error(404, "Endpoint not found")


def cache_watcher():
    """Background thread que actualiza la caché"""
    while True:
        try:
            files = glob.glob(os.path.join(DATA_FOLDER, "*ExposureData*.json"))
            if not files:
                time.sleep(5)
                continue

            sorted_files = sorted(files, key=os.path.getmtime, reverse=True)

            ticker_exp_latest = {}
            for filepath in sorted_files:
                basename = os.path.basename(filepath)

                m = re.search(r"([A-Z]+).*?(\d+dte|weekly|monthly)", basename, re.IGNORECASE)
                if not m:
                    continue

                ticker = m.group(1).upper()
                exp = m.group(2).lower()
                key = f"{ticker}_{exp}"

                if key in ticker_exp_latest:
                    continue

                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()

                ticker_exp_latest[key] = {
                    "file": filepath,
                    "content": content,
                    "mtime": os.path.getmtime(filepath)
                }

            with CACHE_LOCK:
                LATEST_DATA_CACHE.clear()
                LATEST_DATA_CACHE.update(ticker_exp_latest)

            logging.info(f"Cache updated: {len(LATEST_DATA_CACHE)} entries")

        except Exception as e:
            logging.error(f"Cache watcher error: {e}")

        time.sleep(5)


if __name__ == "__main__":
    # Asegurar que las carpetas existen
    os.makedirs(DATA_FOLDER, exist_ok=True)
    os.makedirs(TEMPLATE_FOLDER, exist_ok=True)

    # Iniciar watcher en background
    watcher_thread = threading.Thread(target=cache_watcher, daemon=True)
    watcher_thread.start()

    # Iniciar servidor
    with ThreadedReusableServer(("", PORT), ExposureDataHandler) as httpd:
        print(f"\n{'='*60}")
        print(f"🚀 GEX Dashboard Server - MODULAR VERSION")
        print(f"{'='*60}")
        print(f"📡 Server running on: http://localhost:{PORT}")
        print(f"📁 Serving from: {TEMPLATE_FOLDER}/")
        print(f"📊 Data folder: {DATA_FOLDER}/")
        print(f"📝 Logs: {LOG_FILE}")
        print(f"{'='*60}\n")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n⚠️  Server stopped by user")
            httpd.shutdown()
