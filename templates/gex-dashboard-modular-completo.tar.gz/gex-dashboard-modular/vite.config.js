// vite.config.js - Configuración de Vite para build optimizado

import { defineConfig } from 'vite';
import path from 'path';

export default defineConfig({
  // Directorio raíz
  root: '.',
  
  // Directorio público (assets estáticos)
  publicDir: 'public',
  
  // Build options
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    
    // Generar sourcemaps para debugging
    sourcemap: true,
    
    // Minificar código
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: false, // Mantener console.log
      }
    },
    
    // Configuración de Rollup
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html')
      },
      output: {
        // Code splitting por módulo
        manualChunks: {
          'vendor': ['chart.js'], // Si usas Chart.js u otras libs
          'auth': ['./modules/auth.js'],
          'charts': ['./modules/heatmap.js', './modules/fourier.js', './modules/ib.js'],
          'state': ['./modules/state.js', './modules/storage.js']
        }
      }
    },
    
    // Optimización de chunks
    chunkSizeWarningLimit: 1000,
  },
  
  // Server de desarrollo
  server: {
    port: 3000,
    open: true,
    
    // Proxy para API (si el backend está en otro puerto)
    proxy: {
      '/get_data': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/get_batch': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/get_fourier': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/get_ib': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/get_spots': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/login': {
        target: 'http://localhost:5000',
        changeOrigin: true
      }
    }
  },
  
  // Optimizaciones
  optimizeDeps: {
    include: ['chart.js'], // Pre-bundle dependencies
  },
  
  // Resolve aliases
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './'),
      '@modules': path.resolve(__dirname, './modules'),
      '@utils': path.resolve(__dirname, './modules/utils.js'),
      '@api': path.resolve(__dirname, './modules/api.js'),
      '@state': path.resolve(__dirname, './modules/state.js'),
    }
  },
  
  // Variables de entorno
  define: {
    __APP_VERSION__: JSON.stringify(process.env.npm_package_version || '1.0.0'),
  }
});
