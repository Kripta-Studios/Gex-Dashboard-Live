# Arquitectura Modular - GEX Dashboard

## 📐 Diagrama de Dependencias

```
┌─────────────────────────────────────────────────────────────┐
│                         index.html                          │
│                    (Entry Point HTML)                       │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ <script type="module">
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                          main.js                            │
│                   (Application Coordinator)                 │
│                                                             │
│  • Initialization                                           │
│  • Event listeners                                          │
│  • Window bindings                                          │
└─┬───────┬───────┬───────┬───────┬───────┬───────┬──────────┘
  │       │       │       │       │       │       │
  │       │       │       │       │       │       │
  ▼       ▼       ▼       ▼       ▼       ▼       ▼
┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌─────┐
│auth│ │state│ │api │ │ui  │ │hm  │ │reg │ │stor │
└─┬──┘ └─┬──┘ └─┬──┘ └─┬──┘ └─┬──┘ └─┬──┘ └─┬───┘
  │      │      │      │      │      │      │
  │      │      │      │      │      │      │
  └──────┴──────┴──────┴──────┴──────┴──────┘
                    │
                    │ imports
                    ▼
            ┌───────────────┐
            │   config.js   │
            │   utils.js    │
            └───────────────┘
```

**Leyenda:**
- `auth` = auth.js (Autenticación)
- `state` = state.js (Estado Global)
- `api` = api.js (Fetching de datos)
- `ui` = ui.js / tabs.js (UI Components)
- `hm` = heatmap.js (Heatmaps)
- `reg` = regime.js (Análisis de régimen)
- `stor` = storage.js (Persistencia)

## 🔄 Flujo de Datos

```
┌──────────┐
│  User    │
│  Action  │
└────┬─────┘
     │
     ▼
┌─────────────────┐
│    main.js      │  ← Event Handler
│  (Coordinator)  │
└────┬────────────┘
     │
     ├─────► Check session (auth.js)
     │
     ├─────► Fetch data (api.js)
     │            │
     │            └─────► Server
     │                        │
     │            ┌───────────┘
     │            ▼
     ├─────► Update state (state.js)
     │
     ├─────► Process data (heatmap.js)
     │            │
     │            ├─────► Calculate changes
     │            ├─────► Format values (utils.js)
     │            └─────► Generate regime (regime.js)
     │
     ├─────► Render UI
     │
     └─────► Save to localStorage (storage.js)
```

## 📦 Módulos y Responsabilidades

### 1️⃣ Core (Núcleo)

```
config.js
├── Constantes
├── API endpoints
├── Configuración de intervalos
└── Paletas de colores

utils.js
├── Formateo de números
├── Manejo de fechas
├── Helpers generales
└── Debugging utilities
```

### 2️⃣ State Management

```
state.js
├── appState (objeto global)
├── Gestión de tabs
├── Gestión de charts
└── CRUD operations
```

### 3️⃣ Data Layer

```
api.js
├── fetchChartData()
├── fetchBatchData()
├── fetchFourierData()
├── fetchIBData()
└── updateMarketSpots()
```

### 4️⃣ Business Logic

```
heatmap.js
├── createHeatmapPanel()
│   ├── Aggregate data by strike
│   ├── Track changes (nominal)
│   ├── Calculate top 5 +/-
│   └── Render bars
└── alignChartToSpot()

regime.js
├── generateRegimeHTML()
│   ├── Analyze greek type
│   ├── Determine regime
│   ├── Calculate bias
│   └── Generate descriptive text
└── Color coding logic
```

### 5️⃣ Presentation

```
tabs.js (a crear)
├── renderTabs()
├── Drag & drop
└── Tab interactions

ui.js (a crear)
├── Theme switching
├── Zen mode
└── UI utilities
```

### 6️⃣ Persistence

```
storage.js
├── saveAllLayouts()
├── loadSavedLayouts()
├── takeSnapshot()
└── localStorage management
```

### 7️⃣ Authentication

```
auth.js
├── checkLogin()
├── grantAccess()
├── checkSession()
└── SHA-256 hashing
```

## 🎯 Ventajas de Esta Arquitectura

### Separación de Responsabilidades
- ✅ Cada módulo tiene una función clara
- ✅ Cambios aislados no afectan otros módulos
- ✅ Fácil ubicar código específico

### Testabilidad
```javascript
// Ejemplo: Test de utils.js
import { formatK } from './modules/utils.js';

test('formatK formats 1000 as 1,000k', () => {
  expect(formatK(1000)).toBe('1,000k');
});
```

### Reutilización
```javascript
// Reutilizar en otro proyecto
import { formatK, formatChangePct } from './modules/utils.js';
```

### Performance
```javascript
// Lazy loading
const loadFourier = () => import('./modules/fourier.js');

// Solo se carga cuando se necesita
button.onclick = async () => {
  const { createFourierPanel } = await loadFourier();
  // ...
};
```

### Mantenibilidad
```
Antes: Buscar función en 2300 líneas 😰
Después: Saber exactamente en qué módulo está 😎

Ejemplo:
  ¿Dónde está la función de formateo?
  → modules/utils.js
  
  ¿Dónde está la lógica de heatmap?
  → modules/heatmap.js
```

## 🔌 Puntos de Extensión

Para agregar nuevas features:

```javascript
// 1. Crear nuevo módulo
// modules/newfeature.js
export function newFeature() {
  // ...
}

// 2. Importar en main.js
import { newFeature } from './modules/newfeature.js';

// 3. Exponer si es necesario
window.newFeature = newFeature;

// ¡Listo! Sin tocar otros módulos
```

## 📊 Comparación de Tamaño

```
ANTES (Monolítico):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 2300 líneas
script.js

DESPUÉS (Modular):
━━━━━━━━━━ 300 líneas  main.js
━━━━━ 150           api.js
━━━━━ 130           utils.js
━━━━━━━ 180         storage.js
━━━━━━━━━ 280       heatmap.js
━━━━ 120            state.js
━━━━ 110            regime.js
━━━ 80              auth.js
━━ 50               config.js
━━━━━ 200           fourier.js
━━━━━ 180           ib.js
━━━ 100             tabs.js

Total: ~1880 líneas en 12 archivos
(Más limpio y organizado)
```

## 🚀 Build Pipeline

```
Development:
┌─────────────┐
│  main.js    │
│  (modules)  │
└──────┬──────┘
       │
       │ npm run dev
       │ (Hot reload)
       ▼
┌─────────────┐
│   Browser   │
└─────────────┘

Production:
┌─────────────┐
│  main.js    │
│  (modules)  │
└──────┬──────┘
       │
       │ npm run build
       │ (Vite)
       ▼
┌─────────────┐
│  Rollup     │
│  • Bundle   │
│  • Minify   │
│  • Tree     │
│    shake    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   dist/     │
│  main.js    │
│  (< 100kb)  │
└─────────────┘
```

## 💡 Best Practices Implementadas

1. **Single Responsibility**: Cada módulo hace una cosa
2. **DRY**: No repetir código
3. **KISS**: Mantenerlo simple
4. **Separation of Concerns**: UI, lógica, datos separados
5. **Explicit Dependencies**: Imports claros
6. **Error Handling**: Try-catch en operaciones críticas
7. **Documentation**: JSDoc en funciones públicas
