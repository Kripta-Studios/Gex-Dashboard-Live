#!/usr/bin/env node
/**
 * migrate.js - Script para ayudar a migrar de script.js monolítico a estructura modular
 * 
 * Uso:
 *   node migrate.js analyze   # Analizar script.js y mostrar dependencias
 *   node migrate.js extract   # Extraer módulos faltantes automáticamente
 *   node migrate.js validate  # Validar que todos los módulos estén correctos
 */

const fs = require('fs');
const path = require('path');

const SCRIPT_PATH = './script.js';
const MODULES_DIR = './modules';

// Rangos de líneas para cada módulo a extraer
const MODULE_RANGES = {
  'fourier.js': { start: 1626, end: 1799, description: 'Fourier charts logic' },
  'ib.js': { start: 2054, end: 2234, description: 'Initial Balance charts logic' },
  'tabs.js': { start: 2253, end: 2288, description: 'Tab drag & drop logic' },
  'history.js': { start: 320, end: 425, description: 'History and time scrubbing' },
  'ui.js': { start: 464, end: 494, description: 'UI utilities (zen mode, themes)' },
};

// Analizar dependencias
function analyzeScript() {
  console.log('📊 Analyzing script.js...\n');
  
  const content = fs.readFileSync(SCRIPT_PATH, 'utf-8');
  const lines = content.split('\n');
  
  // Encontrar todas las funciones
  const functions = [];
  const functionRegex = /^(?:async )?function (\w+)/;
  const constFunctionRegex = /^const (\w+) = (?:async )?\(/;
  
  lines.forEach((line, index) => {
    let match = line.match(functionRegex);
    if (!match) match = line.match(constFunctionRegex);
    
    if (match) {
      functions.push({
        name: match[1],
        line: index + 1,
        async: line.includes('async')
      });
    }
  });
  
  console.log(`Found ${functions.length} functions:\n`);
  
  // Agrupar por rango de módulo
  Object.keys(MODULE_RANGES).forEach(moduleName => {
    const range = MODULE_RANGES[moduleName];
    const moduleFunctions = functions.filter(
      f => f.line >= range.start && f.line <= range.end
    );
    
    if (moduleFunctions.length > 0) {
      console.log(`\n📦 ${moduleName} (${range.description})`);
      console.log(`   Lines: ${range.start}-${range.end}`);
      console.log(`   Functions:`);
      moduleFunctions.forEach(f => {
        console.log(`     - ${f.async ? 'async ' : ''}${f.name}() @ line ${f.line}`);
      });
    }
  });
  
  // Funciones ya migradas
  const migratedFunctions = functions.filter(f => f.line < 320 || f.line > 2300);
  console.log(`\n✅ Already migrated: ${migratedFunctions.length} functions`);
  
  // Funciones pendientes
  const pendingCount = functions.length - migratedFunctions.length;
  console.log(`⏳ Pending migration: ${pendingCount} functions\n`);
}

// Extraer módulo específico
function extractModule(moduleName) {
  const range = MODULE_RANGES[moduleName];
  if (!range) {
    console.error(`❌ Unknown module: ${moduleName}`);
    console.log(`Available modules: ${Object.keys(MODULE_RANGES).join(', ')}`);
    return;
  }
  
  console.log(`📤 Extracting ${moduleName}...`);
  
  const content = fs.readFileSync(SCRIPT_PATH, 'utf-8');
  const lines = content.split('\n');
  
  // Extraer líneas del rango
  const moduleLines = lines.slice(range.start - 1, range.end);
  
  // Generar imports necesarios
  const imports = detectImports(moduleLines);
  
  // Generar exports
  const exports = detectExports(moduleLines);
  
  // Construir archivo del módulo
  let moduleContent = `// ${moduleName} - ${range.description}\n\n`;
  
  if (imports.length > 0) {
    imports.forEach(imp => {
      moduleContent += `import ${imp};\n`;
    });
    moduleContent += '\n';
  }
  
  moduleContent += moduleLines.join('\n');
  
  if (exports.length > 0) {
    moduleContent += '\n\n// Exports\n';
    exports.forEach(exp => {
      moduleContent += `export { ${exp} };\n`;
    });
  }
  
  // Guardar módulo
  const modulePath = path.join(MODULES_DIR, moduleName);
  fs.writeFileSync(modulePath, moduleContent);
  
  console.log(`✅ Created ${modulePath}`);
  console.log(`   Functions exported: ${exports.join(', ')}`);
}

// Detectar imports necesarios
function detectImports(lines) {
  const imports = new Set();
  const content = lines.join('\n');
  
  // Detectar uso de funciones de utils
  if (content.includes('formatK(')) imports.add("{ formatK } from './utils.js'");
  if (content.includes('formatChangePct(')) imports.add("{ formatChangePct } from './utils.js'");
  if (content.includes('getCurrentESTMinutes(')) imports.add("{ getCurrentESTMinutes } from './utils.js'");
  
  // Detectar uso de API
  if (content.includes('fetchChartData(')) imports.add("{ fetchChartData } from './api.js'");
  if (content.includes('fetchFourierData(')) imports.add("{ fetchFourierData } from './api.js'");
  if (content.includes('fetchIBData(')) imports.add("{ fetchIBData } from './api.js'");
  
  // Detectar uso de state
  if (content.includes('appState')) imports.add("{ appState } from './state.js'");
  if (content.includes('getCurrentCharts(')) imports.add("{ getCurrentCharts } from './state.js'");
  
  return Array.from(imports);
}

// Detectar exports (funciones públicas)
function detectExports(lines) {
  const exports = [];
  const functionRegex = /^(?:export )?(?:async )?function (\w+)/;
  const constFunctionRegex = /^(?:export )?const (\w+) = (?:async )?\(/;
  
  lines.forEach(line => {
    let match = line.match(functionRegex);
    if (!match) match = line.match(constFunctionRegex);
    
    if (match && !line.startsWith('//')) {
      exports.push(match[1]);
    }
  });
  
  return exports;
}

// Extraer todos los módulos pendientes
function extractAll() {
  console.log('📦 Extracting all pending modules...\n');
  
  Object.keys(MODULE_RANGES).forEach(moduleName => {
    extractModule(moduleName);
    console.log('');
  });
  
  console.log('✅ All modules extracted!');
  console.log('\n📝 Next steps:');
  console.log('   1. Review generated modules in ./modules/');
  console.log('   2. Adjust imports/exports as needed');
  console.log('   3. Update main.js to import new modules');
  console.log('   4. Test the application');
}

// Validar módulos existentes
function validate() {
  console.log('🔍 Validating modules...\n');
  
  if (!fs.existsSync(MODULES_DIR)) {
    console.error('❌ Modules directory not found!');
    return;
  }
  
  const files = fs.readdirSync(MODULES_DIR);
  const jsFiles = files.filter(f => f.endsWith('.js'));
  
  console.log(`Found ${jsFiles.length} module files:\n`);
  
  jsFiles.forEach(file => {
    const filePath = path.join(MODULES_DIR, file);
    const content = fs.readFileSync(filePath, 'utf-8');
    
    // Verificar imports
    const imports = content.match(/^import .* from .*/gm) || [];
    
    // Verificar exports
    const exports = content.match(/^export [({]/gm) || [];
    
    console.log(`📄 ${file}`);
    console.log(`   Imports: ${imports.length}`);
    console.log(`   Exports: ${exports.length}`);
    console.log(`   Size: ${(content.length / 1024).toFixed(2)} KB`);
    
    // Warnings
    if (exports.length === 0) {
      console.log(`   ⚠️  No exports found!`);
    }
    
    console.log('');
  });
}

// CLI
const command = process.argv[2];

switch (command) {
  case 'analyze':
    analyzeScript();
    break;
  
  case 'extract':
    const moduleName = process.argv[3];
    if (moduleName) {
      extractModule(moduleName);
    } else {
      extractAll();
    }
    break;
  
  case 'validate':
    validate();
    break;
  
  default:
    console.log('Usage:');
    console.log('  node migrate.js analyze              # Analyze script.js');
    console.log('  node migrate.js extract              # Extract all modules');
    console.log('  node migrate.js extract fourier.js   # Extract specific module');
    console.log('  node migrate.js validate             # Validate modules');
    console.log('');
    console.log('Available modules to extract:');
    Object.keys(MODULE_RANGES).forEach(name => {
      console.log(`  - ${name}`);
    });
}
