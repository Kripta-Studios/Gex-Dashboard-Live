# 🚀 Guía de Migración - Tu Dashboard Específico

## 📁 Estructura de Carpetas Necesaria

```
tu-proyecto/
├── json_data/                    # Tus archivos de datos JSON
├── templates/                    # Nueva carpeta para archivos web
│   ├── index.html               # HTML modular (nuevo)
│   ├── styles.css               # Tu CSS (sin cambios)
│   ├── main.js                  # Nuevo coordinador principal
│   └── modules/                 # Módulos JavaScript
│       ├── config.js
│       ├── auth.js
│       ├── state.js
│       ├── api.js
│       ├── utils.js
│       ├── heatmap.js
│       ├── regime.js
│       └── storage.js
├── servidor.py                   # Servidor actualizado (nuevo)
└── servidor_logs.txt            # Logs del servidor

```

## 🔧 Pasos de Migración

### Paso 1: Backup de Archivos Actuales

```bash
# Hacer backup de tu configuración actual
cp templates/index.html templates/index.html.backup
cp templates/script.js templates/script.js.backup
cp servidor.py servidor.py.backup
```

### Paso 2: Crear Estructura de Módulos

```bash
# Crear carpeta de módulos
mkdir -p templates/modules

# Descomprimir archivos del paquete modular
cd templates/
# Copiar los archivos de modules/ del paquete a templates/modules/
```

### Paso 3: Actualizar Archivos

#### A. Servidor (servidor.py)

**Cambio principal:** Agregar soporte para servir módulos ES6

```python
# En la función do_GET(), la sección de servir JS:

# 3. SERVIR JS (NUEVO: Incluye módulos)
if path_only.endswith(".js"):
    filename = path_only.lstrip("/")
    
    # Intentar en TEMPLATE_FOLDER directamente (main.js)
    file_path = os.path.join(TEMPLATE_FOLDER, filename)
    
    # Si no existe, intentar en modules/
    if not os.path.exists(file_path) and filename.startswith("modules/"):
        file_path = os.path.join(TEMPLATE_FOLDER, filename)
    
    if os.path.exists(file_path):
        self.send_response(200)
        self.send_header("Content-type", "application/javascript")
        # IMPORTANTE: Header para CORS
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        with open(file_path, "rb") as f:
            self.wfile.write(f.read())
        return
```

**No necesitas cambiar tus endpoints existentes** (`/get_data`, `/get_batch`, `/get_fourier`, `/get_ib`, `/get_spots`, `/login`). ¡Ya funcionan!

#### B. HTML (templates/index.html)

**Cambios necesarios:**

1. **Cambiar el script tag al final:**

```html
<!-- ANTES -->
<script src="script.js"></script>

<!-- DESPUÉS -->
<script type="module" src="main.js"></script>
```

2. **Actualizar onclick handlers:**

```html
<!-- ANTES -->
<button onclick="checkLogin()">AUTHENTICATE</button>

<!-- DESPUÉS -->
<button onclick="window.handleCheckLogin()">AUTHENTICATE</button>
```

**Lista completa de cambios en onclick:**
- `checkLogin()` → `window.handleCheckLogin()`
- `addNewTab()` → `window.handleAddNewTab()`
- `saveAllLayouts()` → `window.handleSaveAllLayouts()`
- `handleLoadData()` → `window.handleLoadData()`
- `handleAddChart()` → `window.handleAddChart()`
- `handleLoadFourier()` → `window.handleLoadFourier()`
- `handleLoadIB()` → `window.handleLoadIB()`
- Los demás ya tienen `window.` así que están bien

3. **Actualizar onchange:**

```html
<!-- ANTES -->
<select onchange="changePalette(this.value)">

<!-- DESPUÉS -->
<select id="theme-select" onchange="window.handleChangePalette(this.value)">
```

#### C. CSS (styles.css)

**¡No necesitas cambiar NADA!** El CSS es compatible 100%.

### Paso 4: Copiar Módulos

Copia todos los archivos del paquete modular:

```bash
# En templates/
cp /ruta/al/paquete/modules/*.js modules/
cp /ruta/al/paquete/main.js .
```

### Paso 5: Probar

```bash
# Detener servidor actual si está corriendo
# Ctrl+C

# Iniciar servidor actualizado
python3 servidor.py
```

Abrir navegador en `http://localhost:8609`

## ✅ Checklist de Verificación

Después de migrar, verifica que funcione:

- [ ] Login con credenciales
- [ ] Cargar chart con LOAD
- [ ] Agregar chart con +
- [ ] Cambiar entre tabs
- [ ] Fourier charts
- [ ] IB charts (solo si eres ADMIN)
- [ ] Auto-refresh
- [ ] Guardar layout (SAVE)
- [ ] Recargar página (debe restaurar layout)
- [ ] Pop out window
- [ ] Zen mode
- [ ] Theme selector
- [ ] Market spots se actualizan

## 🐛 Troubleshooting

### Error: "Cannot use import statement outside a module"

**Causa:** Falta `type="module"` en el script tag

**Solución:**
```html
<script type="module" src="main.js"></script>
```

### Error: "Failed to load module script"

**Causa:** El servidor no está sirviendo los archivos .js correctamente

**Solución:** Verificar que el servidor.py tenga el código actualizado para servir módulos

### Error: "X is not defined" en console

**Causa:** Función no exportada a window

**Solución:** Verificar que en main.js esté:
```javascript
window.nombreFuncion = nombreFuncion;
```

### Charts no se cargan después de login

**Causa:** Falta llamar a `init()` después del login

**Solución:** Verificar en main.js:
```javascript
async function handleCheckLogin() {
  const result = await checkLogin();
  if (result.success) {
    grantAccess(result.role);
    init();  // ← Esto debe estar
  }
}
```

### Layouts no se guardan

**Causa:** localStorage bloqueado o error en storage.js

**Solución:**
1. Abrir DevTools (F12)
2. Ver Console para errores
3. Verificar que storage.js esté cargado
4. Probar en ventana normal (no incognito)

## 📊 Comparación Antes/Después

### Antes (Monolítico)
```
templates/
├── index.html
├── styles.css
└── script.js (2300 líneas) ← Difícil de mantener
```

### Después (Modular)
```
templates/
├── index.html (actualizado)
├── styles.css (sin cambios)
├── main.js (300 líneas) ← Coordinador
└── modules/
    ├── config.js (50)
    ├── auth.js (80)
    ├── state.js (120)
    ├── api.js (150)
    ├── utils.js (130)
    ├── heatmap.js (280)
    ├── regime.js (110)
    └── storage.js (180)
```

**Ventajas:**
- ✅ Más fácil encontrar código
- ✅ Cambios aislados
- ✅ Mejor para git (menos conflictos)
- ✅ Más fácil testear
- ✅ Reutilizable

## 🔄 Mantener Ambas Versiones (Transición Suave)

Puedes mantener ambas versiones temporalmente:

```
templates/
├── index.html           # Versión antigua
├── index-modular.html   # Versión nueva
├── script.js            # Versión antigua
├── main.js              # Versión nueva
├── styles.css           # Compartido
└── modules/             # Solo para versión nueva
```

Acceder:
- Versión antigua: `http://localhost:8609/`
- Versión nueva: `http://localhost:8609/index-modular.html`

Una vez verificado que todo funciona, reemplazar:
```bash
mv templates/index.html templates/index-legacy.html
mv templates/index-modular.html templates/index.html
```

## 📝 Notas Importantes

1. **No toques tus archivos JSON** - La migración no afecta tu carpeta `json_data/`

2. **El servidor es compatible** - Todos tus endpoints actuales siguen funcionando igual

3. **CSS sin cambios** - El styles.css no necesita modificaciones

4. **Funcionalidad 100% equivalente** - Todo lo que funcionaba antes, funciona después

5. **Puedes migrar gradualmente** - Los módulos faltantes (fourier, ib, tabs, history) pueden extraerse después con el script `migrate.js`

## 🎯 Próximos Pasos (Opcional)

Una vez que la versión modular funcione:

1. **Extraer módulos faltantes:**
   ```bash
   node migrate.js extract fourier.js
   node migrate.js extract ib.js
   ```

2. **Agregar tests:**
   ```bash
   npm install
   npm run test
   ```

3. **Build para producción:**
   ```bash
   npm run build
   # Genera dist/ con código optimizado
   ```

## 📞 Soporte

Si algo no funciona:

1. Abre DevTools (F12)
2. Ve a Console
3. Busca errores en rojo
4. Verifica Network tab que los archivos .js se cargan bien
5. Compara con los archivos de ejemplo

¡La migración debería ser suave! 🚀
