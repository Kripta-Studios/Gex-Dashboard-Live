// main.js - Punto de entrada principal adaptado para tu HTML

import { checkLogin, grantAccess, checkSession } from './modules/auth.js';
import { appState, getCurrentCharts, addChartToCurrent, removeChart, switchTab, addNewTab, closeTab, renameTab } from './modules/state.js';
import { fetchChartData, fetchBatchData, fetchFourierData, fetchIBData, updateMarketSpots } from './modules/api.js';
import { updateNYTime, getTodayString, getCurrentESTMinutes, scrubHistory as scrubHistoryUtil } from './modules/utils.js';
import { createHeatmapPanel, alignChartToSpot } from './modules/heatmap.js';
import { saveAllLayouts, loadSavedLayouts, takeSnapshot } from './modules/storage.js';
import { REFRESH_INTERVAL } from './modules/config.js';

// =============================================================================
// EXPONER FUNCIONES GLOBALES (para onclick handlers en HTML)
// =============================================================================

window.handleCheckLogin = handleCheckLogin;
window.handleAddNewTab = handleAddNewTabHandler;
window.handleSwitchTab = switchTabHandler;
window.handleCloseTab = closeTabHandler;
window.handleRenameTab = renameTabHandler;
window.handleSaveAllLayouts = saveAllLayouts;
window.takeSnapshot = takeSnapshot;
window.handleChangePalette = changePalette;
window.toggleZenMode = toggleZenMode;
window.handleLoadData = handleLoadData;
window.handleAddChart = handleAddChart;
window.handleLoadFourier = handleLoadFourier;
window.handleLoadIB = handleLoadIB;
window.handleToggleAutoRefresh = toggleAutoRefresh;
window.realignAllCharts = realignAllCharts;
window.popoutCurrentLayout = popoutCurrentLayout;
window.updateExpSuggestions = updateExpSuggestions;
window.handleWrapperDragOver = handleWrapperDragOver;
window.removeChart = removeChartHandler;
window.openDetachedWindow = openDetachedWindow;
window.scrubHistory = scrubHistoryWrapper;
window.loadHistoryNow = loadHistoryNow;
window.goLive = goLive;
window.playHistory = playHistory;

// =============================================================================
// INICIALIZACIÓN
// =============================================================================

async function init() {
  console.log('[INIT] Starting GEX Dashboard - Modular Version');
  
  const urlParams = new URLSearchParams(window.location.search);
  const mode = urlParams.get('mode');

  // Modo detached (ventana popup)
  if (mode === 'detached' || mode === 'detached_layout') {
    await initDetachedMode(urlParams);
    return;
  }

  // Modo normal - Cargar layouts guardados
  const loaded = await loadSavedLayouts();
  
  if (loaded) {
    console.log('[INIT] Layouts loaded from localStorage');
    renderTabs();
    renderAllCharts();
  } else {
    console.log('[INIT] No saved layouts found');
  }

  // Actualizar información de mercado
  updateMarketSpots();
  updateNYTime();
  
  // Intervalos periódicos
  setInterval(updateNYTime, 1000);
  setInterval(updateMarketSpots, 10000);
  
  // Auto-refresh si está activado
  const autoRefreshCheck = document.getElementById("auto-refresh");
  if (autoRefreshCheck && autoRefreshCheck.checked) {
    toggleAutoRefresh();
  }
  
  console.log('[INIT] Application ready');
}

// =============================================================================
// AUTENTICACIÓN
// =============================================================================

async function handleCheckLogin() {
  const result = await checkLogin();
  if (result.success) {
    grantAccess(result.role);
    init();
  }
}

// =============================================================================
// GESTIÓN DE TABS
// =============================================================================

function renderTabs() {
  const tabsDiv = document.getElementById("tab-container");
  if (!tabsDiv) return;
  
  // Limpiar tabs existentes (excepto el botón +)
  const newTabBtn = tabsDiv.querySelector('.new-tab-btn');
  tabsDiv.innerHTML = "";
  
  appState.tabs.forEach((tab, index) => {
    const tabEl = document.createElement("div");
    tabEl.className = "tab";
    if (tab.id === appState.currentTabId) tabEl.classList.add("active");
    
    tabEl.dataset.index = index;
    tabEl.draggable = true;
    
    tabEl.innerHTML = `
      <span class="tab-name">${tab.name}</span>
      ${appState.tabs.length > 1 ? `<button class="tab-close" onclick="window.handleCloseTab(${tab.id}); event.stopPropagation();">×</button>` : ''}
    `;
    
    tabEl.onclick = (e) => {
      if (!e.target.classList.contains('tab-close')) {
        window.handleSwitchTab(tab.id);
      }
    };
    
    tabEl.ondblclick = () => window.handleRenameTab(tab.id);
    
    // Drag & Drop handlers
    tabEl.addEventListener('dragstart', handleTabDragStart);
    tabEl.addEventListener('dragover', handleTabDragOver);
    tabEl.addEventListener('drop', handleTabDrop);
    tabEl.addEventListener('dragend', handleTabDragEnd);
    
    tabsDiv.appendChild(tabEl);
  });
  
  // Re-añadir botón +
  if (newTabBtn) {
    tabsDiv.appendChild(newTabBtn);
  }
}

function switchTabHandler(id) {
  switchTab(id);
  renderTabs();
  renderAllCharts();
}

function handleAddNewTabHandler() {
  addNewTab();
  renderTabs();
  switchTabHandler(appState.tabs[appState.tabs.length - 1].id);
}

function closeTabHandler(id) {
  if (closeTab(id)) {
    renderTabs();
    renderAllCharts();
  }
}

function renameTabHandler(id) {
  const newName = prompt("New tab name:");
  if (newName && renameTab(id, newName)) {
    renderTabs();
  }
}

// Drag & Drop de tabs
let draggedTabIndex = null;

function handleTabDragStart(e) {
  draggedTabIndex = parseInt(this.dataset.index);
  this.style.opacity = '0.5';
  e.dataTransfer.effectAllowed = 'move';
}

function handleTabDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  return false;
}

function handleTabDrop(e) {
  e.stopPropagation();
  e.preventDefault();

  const allTabs = document.querySelectorAll('.tab');
  allTabs.forEach(t => t.style.opacity = '1');
  
  const targetIndex = parseInt(this.dataset.index);
  
  if (draggedTabIndex !== null && draggedTabIndex !== targetIndex) {
    const movedTab = appState.tabs.splice(draggedTabIndex, 1)[0];
    appState.tabs.splice(targetIndex, 0, movedTab);
    
    renderTabs();
    saveAllLayouts();
  }
  
  draggedTabIndex = null;
}

function handleTabDragEnd(e) {
  this.style.opacity = '1';
}

// =============================================================================
// RENDERIZADO DE CHARTS
// =============================================================================

function renderAllCharts() {
  const wrapper = document.getElementById("charts-wrapper");
  if (!wrapper) return;
  
  wrapper.scrollLeft = 0;
  const activeCharts = getCurrentCharts();
  wrapper.innerHTML = "";
  
  if (activeCharts.length === 0) {
    wrapper.innerHTML = '<div style="width:100%; text-align:center; padding-top:100px; color:var(--text-dim);">Empty Layout</div>';
    return;
  }
  
  activeCharts.forEach((chartObj, index) => {
    const panel = createChartPanel(chartObj, index);
    wrapper.appendChild(panel);
    
    // Drag handlers para charts
    panel.addEventListener('dragstart', handleChartDragStart);
    panel.addEventListener('dragend', handleChartDragEnd);
    
    setTimeout(() => alignChartToSpot(panel), 50);
  });
}

function createChartPanel(chartObj, index) {
  // Dispatcher por tipo de chart
  if (chartObj.type === 'fourier') {
    // TODO: Implementar cuando se extraiga módulo fourier
    return createHeatmapPanel(chartObj, index);
  }
  if (chartObj.type === 'ib') {
    // TODO: Implementar cuando se extraiga módulo ib
    return createHeatmapPanel(chartObj, index);
  }
  
  return createHeatmapPanel(chartObj, index);
}

function removeChartHandler(index) {
  removeChart(index);
  renderAllCharts();
}

// Drag & Drop de charts
function handleChartDragStart(e) {
  this.classList.add('dragging');
}

function handleChartDragEnd(e) {
  this.classList.remove('dragging');
}

function handleWrapperDragOver(e) {
  e.preventDefault();
  const container = document.getElementById("charts-wrapper");
  const afterElement = getDragAfterElement(container, e.clientX);
  const draggable = document.querySelector(".dragging");
  
  if (draggable) {
    if (afterElement == null) {
      container.appendChild(draggable);
    } else {
      container.insertBefore(draggable, afterElement);
    }
  }
}

function getDragAfterElement(container, x) {
  const draggableElements = [...container.querySelectorAll('.chart-panel:not(.dragging)')];
  
  return draggableElements.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = x - box.left - box.width / 2;
    
    if (offset < 0 && offset > closest.offset) {
      return { offset: offset, element: child };
    } else {
      return closest;
    }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

// =============================================================================
// CARGA DE DATOS
// =============================================================================

function getParams() {
  const t = document.getElementById("ticker");
  const e = document.getElementById("exp");
  const g = document.getElementById("greek-select");
  
  return {
    ticker: t.value.toUpperCase(),
    exp: e.value.toLowerCase(),
    greek: g.value,
  };
}

async function handleLoadData() {
  const currentTab = appState.tabs.find((t) => t.id === appState.currentTabId);
  if (!currentTab) return;
  
  currentTab.charts = [];
  const params = getParams();
  const data = await fetchChartData(params.ticker, params.exp);
  
  if (data) {
    addChartToCurrent(data, params);
    renderAllCharts();
  }
}

async function handleAddChart() {
  const params = getParams();
  const btn = document.querySelector(".btn-add");
  if (btn) btn.innerText = "...";
  
  const data = await fetchChartData(params.ticker, params.exp);
  if (btn) btn.innerText = "+";
  
  if (data) {
    addChartToCurrent(data, params);
    renderAllCharts();
  }
}

async function handleLoadFourier() {
  const ticker = document.getElementById("ticker").value.toUpperCase();
  const dateInput = document.getElementById("fourier-date");
  const dateStr = dateInput && dateInput.value ? dateInput.value.replace(/-/g, '') : getTodayString();
  
  const data = await fetchFourierData(ticker, dateStr);
  
  if (data) {
    const currentTab = appState.tabs.find((t) => t.id === appState.currentTabId);
    if (currentTab) {
      currentTab.charts.push({
        data: data,
        inputTicker: ticker,
        inputExp: 'fourier',
        type: 'fourier',
        dateStr: dateStr
      });
      renderAllCharts();
    }
  }
}

async function handleLoadIB() {
  const ticker = document.getElementById("ticker").value.toUpperCase();
  const dateInput = document.getElementById("fourier-date");
  const dateStr = dateInput && dateInput.value ? dateInput.value.replace(/-/g, '') : getTodayString();
  
  const data = await fetchIBData(ticker, dateStr);
  
  if (data) {
    const currentTab = appState.tabs.find((t) => t.id === appState.currentTabId);
    if (currentTab) {
      currentTab.charts.push({
        data: data,
        inputTicker: ticker,
        inputExp: 'ib',
        type: 'ib',
        dateStr: dateStr
      });
      renderAllCharts();
    }
  }
}

// =============================================================================
// AUTO-REFRESH
// =============================================================================

function toggleAutoRefresh() {
  const chk = document.getElementById("auto-refresh");
  const ind = document.getElementById("timer-indicator");
  
  if (chk && chk.checked) {
    if (ind) ind.style.display = "block";
    if (!appState.refreshIntervalId) {
      appState.refreshIntervalId = setInterval(refreshDashboard, REFRESH_INTERVAL);
    }
  } else {
    if (ind) ind.style.display = "none";
    if (appState.refreshIntervalId) {
      clearInterval(appState.refreshIntervalId);
      appState.refreshIntervalId = null;
    }
  }
}

async function refreshDashboard() {
  const currentTab = appState.tabs.find(t => t.id === appState.currentTabId);
  if (!currentTab || currentTab.charts.length === 0) return;

  const requestList = currentTab.charts
    .filter(c => c.type === 'heatmap' || !c.type)
    .map(c => ({
      ticker: c.inputTicker,
      exp: c.inputExp
    }));

  if (requestList.length === 0) return;

  const uniqueRequests = [...new Set(requestList.map(JSON.stringify))].map(JSON.parse);
  const batchData = await fetchBatchData(uniqueRequests);
  
  if (batchData) {
    currentTab.charts.forEach(chart => {
      if (chart.type === 'heatmap' || !chart.type) {
        const dataKey = `${chart.inputTicker.toUpperCase()}_${chart.inputExp.toLowerCase()}`;
        if (batchData[dataKey]) {
          chart.data = batchData[dataKey];
        }
      }
    });

    updateMarketSpots();
    updateNYTime();
    renderAllCharts();
  }
}

// =============================================================================
// UI UTILITIES
// =============================================================================

function changePalette(theme) {
  document.body.className = theme;
  console.log('[UI] Theme changed to:', theme);
}

function toggleZenMode() {
  document.body.classList.toggle('zen-mode');
}

function realignAllCharts() {
  const panels = document.querySelectorAll('.chart-panel');
  panels.forEach(panel => {
    setTimeout(() => alignChartToSpot(panel), 10);
  });
}

function updateExpSuggestions() {
  // TODO: Implementar sugerencias de expiración
  console.log('[UI] Update exp suggestions');
}

function openDetachedWindow(index) {
  const charts = getCurrentCharts();
  const chart = charts[index];
  if (!chart) return;

  const params = new URLSearchParams({
    mode: 'detached',
    ticker: chart.inputTicker,
    exp: chart.inputExp,
    greek: chart.greek,
    type: chart.type || 'heatmap'
  });

  if (chart.dateStr) {
    params.append('date', chart.dateStr);
  }

  const w = 800, h = 900;
  const left = (screen.width / 2) - (w / 2);
  const top = (screen.height / 2) - (h / 2);
  
  window.open(
    `${window.location.pathname}?${params.toString()}`,
    '_blank',
    `width=${w},height=${h},left=${left},top=${top}`
  );
}

function popoutCurrentLayout() {
  const transferId = `layout_${Date.now()}`;
  const chartsConfig = getCurrentCharts();
  
  if (chartsConfig.length === 0) {
    alert('No charts to pop out');
    return;
  }
  
  localStorage.setItem(transferId, JSON.stringify(chartsConfig));
  
  const themeSelect = document.getElementById("theme-select");
  const theme = themeSelect ? themeSelect.value : 'default';
  
  const params = new URLSearchParams({
    mode: 'detached_layout',
    transferId: transferId,
    theme: theme
  });
  
  window.open(
    `${window.location.pathname}?${params.toString()}`,
    '_blank',
    'width=1600,height=900'
  );
}

// =============================================================================
// HISTORY / TIME MACHINE
// =============================================================================

function scrubHistoryWrapper(value) {
  const normalized = scrubHistoryUtil(parseInt(value));
  appState.currentHistoryTimeEST = normalized;
  
  const historyTimeEl = document.getElementById("history-time");
  if (historyTimeEl) {
    const hours = Math.floor(normalized / 60);
    const mins = normalized % 60;
    historyTimeEl.textContent = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  }
}

function loadHistoryNow() {
  console.log('[HISTORY] Load data for:', appState.currentHistoryTimeEST);
  // TODO: Implementar carga de datos históricos
}

function goLive() {
  const slider = document.getElementById("history-slider");
  const historyTimeEl = document.getElementById("history-time");
  
  if (slider) slider.value = 100;
  if (historyTimeEl) historyTimeEl.textContent = 'LIVE';
  
  appState.currentHistoryTimeEST = null;
  refreshDashboard();
}

function playHistory() {
  console.log('[HISTORY] Play history animation');
  // TODO: Implementar reproducción de historial
}

// =============================================================================
// MODO DETACHED
// =============================================================================

async function initDetachedMode(urlParams) {
  document.body.classList.add('detached-mode');
  
  const theme = urlParams.get('theme');
  if (theme) changePalette(theme);
  
  const type = urlParams.get('type');
  const ticker = urlParams.get('ticker');
  const exp = urlParams.get('exp');
  const greek = urlParams.get('greek');
  const dateStr = urlParams.get('date');
  
  const wrapper = document.getElementById("charts-wrapper");
  if (!wrapper) return;
  
  wrapper.innerHTML = '<div style="color:white; margin:auto;">Loading...</div>';
  
  let data = null;
  
  if (type === 'fourier') {
    data = await fetchFourierData(ticker, dateStr);
  } else if (type === 'ib') {
    data = await fetchIBData(ticker, dateStr);
  } else {
    data = await fetchChartData(ticker, exp);
  }
  
  if (data) {
    wrapper.innerHTML = "";
    const chartConf = { 
      data: data, 
      greek: greek,
      inputTicker: ticker, 
      inputExp: exp,
      type: type || 'heatmap',
      dateStr: dateStr
    };
    
    const panel = createChartPanel(chartConf, 0);
    wrapper.appendChild(panel);
    
    // Ocultar controles de close/popout
    const closeBtn = panel.querySelector('.btn-close');
    const popBtn = panel.querySelector('.btn-popout');
    if (closeBtn) closeBtn.style.display = 'none';
    if (popBtn) popBtn.style.display = 'none';
    
    setTimeout(() => alignChartToSpot(panel), 100);
  } else {
    wrapper.innerHTML = `<div style="color:red; text-align:center; padding-top:50px;">Data not found</div>`;
  }
  
  console.log('[DETACHED] Mode initialized');
}

// =============================================================================
// VERIFICACIÓN DE SESIÓN AL CARGAR
// =============================================================================

(function checkSessionOnLoad() {
  const urlParams = new URLSearchParams(window.location.search);
  const session = checkSession();
  
  if (session.valid || urlParams.get('mode') === 'detached') {
    if (!session.valid) {
      sessionStorage.setItem("gex_auth_token", "valid");
    }
    grantAccess(session.role || 'USER');
    init();
  }
})();

// =============================================================================
// EVENT LISTENERS
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
  const loginPassInput = document.getElementById("login-pass");
  if (loginPassInput) {
    loginPassInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") handleCheckLogin();
    });
  }
});

console.log('[MAIN] Module loaded successfully');
